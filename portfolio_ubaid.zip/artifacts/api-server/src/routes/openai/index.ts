import { Router, type IRouter } from "express";
import { db, conversations, messages } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { openai } from "@workspace/integrations-openai-ai-server";
import { speechToText, textToSpeech } from "@workspace/integrations-openai-ai-server/audio";
import {
  CreateOpenaiConversationBody,
  SendOpenaiMessageBody,
  GetOpenaiConversationParams,
  DeleteOpenaiConversationParams,
  ListOpenaiMessagesParams,
  SendOpenaiMessageParams,
  ListOpenaiConversationsResponse,
  GetOpenaiConversationResponse,
  ListOpenaiMessagesResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const PORTFOLIO_SYSTEM_PROMPT = `You are a warm, friendly AI assistant representing Ubaid's portfolio. Speak in a soft, helpful tone — like a knowledgeable friend, not a salesperson.

IMPORTANT: Detect the language of the user's message and ALWAYS reply in that exact same language. If the user writes in Urdu, reply in Urdu. If in English, reply in English. If in Roman Urdu (Urdu written in English letters), reply in Roman Urdu. Never switch languages.

About Ubaid:
- Name: Ubaid
- Education: BS Software Engineering (in progress)
- Skills: AI specialist, ML model training, Python development, chatbot development
- Projects: AI Desktop Assistant (a voice-controlled AI app), multiple AI chatbots, Python automation tools
- Services: Python problem solving, ML model training, AI system building (ChatGPT-style apps)
- Contact: WhatsApp 03051710343, or the Contact page

When asked about:
- Skills → mention AI specialist, ML model training, Python, chatbot development
- Projects → mention AI Desktop Assistant, chatbots he's built, automation tools
- Education → BS Software Engineering

Rules: Keep replies to 2-3 short sentences max. Be warm and encouraging. For pricing, say it's per-project — direct them to Contact page or WhatsApp.`;

router.get("/openai/conversations", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(conversations)
    .orderBy(conversations.createdAt);
  res.json(ListOpenaiConversationsResponse.parse(rows));
});

router.post("/openai/conversations", async (req, res): Promise<void> => {
  const parsed = CreateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [conversation] = await db
    .insert(conversations)
    .values({ title: parsed.data.title })
    .returning();

  res.status(201).json(conversation);
});

router.get("/openai/conversations/:id", async (req, res): Promise<void> => {
  const params = GetOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, params.data.id));

  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, params.data.id))
    .orderBy(asc(messages.createdAt));

  res.json(GetOpenaiConversationResponse.parse({ ...conversation, messages: msgs }));
});

router.delete("/openai/conversations/:id", async (req, res): Promise<void> => {
  const params = DeleteOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(conversations)
    .where(eq(conversations.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/openai/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = ListOpenaiMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, params.data.id))
    .orderBy(asc(messages.createdAt));

  res.json(ListOpenaiMessagesResponse.parse(msgs));
});

router.post("/openai/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = SendOpenaiMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = SendOpenaiMessageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { id } = params.data;
  const { content } = body.data;

  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, id));

  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  await db.insert(messages).values({
    conversationId: id,
    role: "user",
    content,
  });

  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(asc(messages.createdAt));

  const chatMessages = [
    { role: "system" as const, content: PORTFOLIO_SYSTEM_PROMPT },
    ...history.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
  ];

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      messages: chatMessages,
      stream: true,
    });

    for await (const chunk of stream) {
      const chunkContent = chunk.choices[0]?.delta?.content;
      if (chunkContent) {
        fullResponse += chunkContent;
        res.write(`data: ${JSON.stringify({ content: chunkContent })}\n\n`);
      }
    }

    await db.insert(messages).values({
      conversationId: id,
      role: "assistant",
      content: fullResponse,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "AI error";
    res.write(`data: ${JSON.stringify({ content: `Sorry, something went wrong: ${msg}` })}\n\n`);
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

router.post("/openai/transcribe", async (req, res): Promise<void> => {
  try {
    const { audio, mimeType } = req.body as { audio: string; mimeType?: string };
    if (!audio) {
      res.status(400).json({ error: "Missing audio data" });
      return;
    }
    const buffer = Buffer.from(audio, "base64");
    const fmt = (mimeType?.includes("webm") ? "webm" : mimeType?.includes("mp4") ? "mp4" : "webm") as "webm" | "mp4";
    const text = await speechToText(buffer, fmt);
    res.json({ text });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Transcription failed";
    res.status(500).json({ error: msg });
  }
});

router.post("/openai/tts", async (req, res): Promise<void> => {
  try {
    const { text } = req.body as { text: string };
    if (!text) {
      res.status(400).json({ error: "Missing text" });
      return;
    }
    const buffer = await textToSpeech(text.slice(0, 500));
    res.setHeader("Content-Type", "audio/mpeg");
    res.send(buffer);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "TTS failed";
    res.status(500).json({ error: msg });
  }
});

export default router;
