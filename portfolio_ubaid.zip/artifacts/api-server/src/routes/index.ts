import { Router, type IRouter } from "express";
import healthRouter from "./health";
import contactRouter from "./contact";
import openaiRouter from "./openai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(contactRouter);
router.use(openaiRouter);

export default router;
