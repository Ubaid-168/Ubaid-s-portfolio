import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, CheckCircle } from "lucide-react";
import { SiPython, SiOpenai } from "react-icons/si";
import { Brain } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

const services = [
  {
    id: "python",
    icon: SiPython,
    title: "Python Problem Solving",
    tagline: "Stuck on Python? I'll unstick you.",
    description:
      "From assignment bugs to production scripts — I debug, refactor, and build Python solutions that work. No hand-waving, no vague explanations. Just working code with clear comments.",
    features: [
      "Bug fixing and code debugging",
      "Algorithm implementation",
      "Automation scripts and bots",
      "REST API development (FastAPI, Flask, Django)",
      "Data processing with pandas, NumPy",
      "File parsing, web scraping, task automation",
    ],
    badge: "Most popular",
  },
  {
    id: "ml",
    icon: Brain,
    title: "ML Model Training",
    tagline: "From raw data to trained model.",
    description:
      "I train, evaluate, and optimize machine learning models tailored to your dataset. Whether you need a classifier, regression model, or neural network, I handle the full pipeline.",
    features: [
      "Classification and regression models",
      "Neural networks (CNNs, RNNs, Transformers)",
      "Training pipelines with scikit-learn & PyTorch",
      "Model evaluation, tuning, and validation",
      "Feature engineering and preprocessing",
      "Model export and deployment",
    ],
    badge: "Research-grade",
  },
  {
    id: "ai",
    icon: SiOpenai,
    title: "AI System Building",
    tagline: "Build your own ChatGPT-style AI.",
    description:
      "LLM integration, fine-tuning, RAG pipelines, chatbots, and full AI-powered applications. I build the kind of AI systems you see in startups and research labs.",
    features: [
      "LLM integration (OpenAI, Hugging Face, Llama)",
      "Fine-tuning on custom datasets",
      "RAG (Retrieval-Augmented Generation) systems",
      "AI chatbot development and deployment",
      "Prompt engineering and optimization",
      "Production AI API architecture",
    ],
    badge: "Advanced",
  },
];

export default function Services() {
  return (
    <Layout>
      <section className="py-20 border-b border-border/30">
        <div className="container mx-auto px-4">
          <ScrollReveal direction="up">
            <div className="max-w-2xl">
              <Badge className="mb-4 font-mono text-xs border-primary/40 text-primary bg-primary/10 px-3 py-1">
                Services
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                What I can build for you
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Specialized in Python, machine learning, and AI systems. Every engagement starts with understanding your specific problem — then delivering a working solution.
              </p>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4 space-y-12">
          {services.map((service, idx) => {
            const Icon = service.icon;
            return (
              <ScrollReveal key={service.id} direction="up" delay={idx * 80}>
                <div
                  className="border border-border/40 rounded-xl p-8 bg-card/30 hover:border-primary/30 transition-all duration-300 group"
                  data-testid={`card-service-${service.id}`}
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <Badge variant="outline" className="font-mono text-xs border-accent/40 text-accent">
                          {service.badge}
                        </Badge>
                      </div>
                      <h2 className="text-2xl font-bold mb-2 tracking-tight group-hover:text-primary transition-colors">
                        {service.title}
                      </h2>
                      <p className="text-sm font-mono text-primary mb-4">{service.tagline}</p>
                      <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                      <div className="mt-6">
                        <Link href="/contact">
                          <Button className="font-mono gap-2 bg-primary text-primary-foreground hover:bg-primary/90" data-testid={`button-inquire-${service.id}`}>
                            Inquire <ArrowRight className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-4">What's included</p>
                      <ul className="space-y-3">
                        {service.features.map((feature) => (
                          <li key={feature} className="flex gap-3 text-sm text-muted-foreground">
                            <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </section>

      <section className="py-20 border-t border-border/30">
        <div className="container mx-auto px-4">
          <ScrollReveal direction="up">
            <div className="border border-border/40 rounded-xl p-10 bg-card/30 text-center">
              <h2 className="text-2xl md:text-3xl font-bold mb-3 tracking-tight">Pricing is per project</h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                Every problem is different, so every quote is too. Describe your project and I'll respond with a scope and timeline estimate.
              </p>
              <Link href="/contact">
                <Button size="lg" className="font-mono gap-2 bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-get-quote">
                  Get a Quote <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </Layout>
  );
}
