import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Brain, Cpu, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { SiPython, SiOpenai } from "react-icons/si";
import { ScrollReveal } from "@/components/ScrollReveal";
import { useState } from "react";

const faqs = [
  {
    q: "What kind of Python problems can you solve?",
    a: "Anything from assignment bugs and automation scripts to REST APIs and data processing pipelines. If it's Python, I can handle it.",
  },
  {
    q: "How long does a project take?",
    a: "Depends on complexity — small scripts can be done in hours, ML models typically take a few days, and full AI systems take 1–2 weeks. I'll give you a clear timeline upfront.",
  },
  {
    q: "Can you build a ChatGPT-style chatbot for my business?",
    a: "Yes! I specialize in exactly this — LLM integration, custom knowledge bases, and deploying AI chat systems for real use cases.",
  },
  {
    q: "How do I get started?",
    a: "Send me a message on WhatsApp (03051710343) or use the Contact page. Describe your problem and I'll get back with a plan within 24 hours.",
  },
  {
    q: "Do you work with students?",
    a: "Absolutely — students are a big part of who I help. Python assignments, ML projects, final year projects — all welcome.",
  },
  {
    q: "What is your pricing?",
    a: "Every project is quoted individually based on scope. Reach out via the Contact page or WhatsApp and I'll give you a fair, transparent estimate.",
  },
];

function FAQItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(false);
  return (
    <ScrollReveal direction="up" delay={index * 60}>
      <div
        className="rounded-xl overflow-hidden transition-all duration-300 cursor-pointer glass-card hover:border-primary/30"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center justify-between px-6 py-4 gap-4">
          <span className="font-mono text-sm font-medium text-foreground">{q}</span>
          {open
            ? <ChevronUp className="w-4 h-4 flex-shrink-0 text-primary" />
            : <ChevronDown className="w-4 h-4 flex-shrink-0 text-muted-foreground" />}
        </div>
        {open && (
          <div className="px-6 pb-4 text-sm text-muted-foreground leading-relaxed border-t border-white/5">
            <p className="pt-3">{a}</p>
          </div>
        )}
      </div>
    </ScrollReveal>
  );
}

export default function Home() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative min-h-screen flex flex-col justify-center overflow-hidden ai-grid">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full blur-3xl opacity-12" style={{ background: "radial-gradient(circle, hsl(173 80% 42% / 0.15), transparent)" }} />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl opacity-10" style={{ background: "radial-gradient(circle, hsl(280 80% 62% / 0.12), transparent)" }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full blur-3xl opacity-5" style={{ background: "hsl(173 80% 42%)" }} />
        </div>

        <div className="container mx-auto px-4 py-24 relative z-10">
          <ScrollReveal direction="up">
            <div className="max-w-4xl">
              <Badge className="mb-6 font-mono text-xs px-3 py-1" style={{
                background: "rgba(20,184,166,0.1)",
                border: "1px solid rgba(20,184,166,0.4)",
                color: "hsl(173 80% 42%)",
                boxShadow: "0 0 15px rgba(20,184,166,0.2)",
              }}>
                ⚡ Available for projects
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold leading-tight tracking-tight mb-6">
                I build{" "}
                <span className="font-mono gradient-text">&lt;AI&gt;</span>
                {" "}systems
                <br />
                that actually{" "}
                <span className="text-accent" style={{ textShadow: "0 0 30px hsl(280 80% 62% / 0.5)" }}>work</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-10 max-w-2xl leading-relaxed">
                Python expert. ML model trainer. AI systems builder. I help students and teams solve real coding problems — from debugging scripts to deploying production-grade AI.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/services">
                  <button className="glow-btn font-mono text-sm font-medium px-6 py-3 rounded-lg text-white flex items-center gap-2" data-testid="button-view-services">
                    View Services <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
                <Link href="/contact">
                  <button className="glow-btn-outline font-mono text-sm font-medium px-6 py-3 rounded-lg text-foreground flex items-center gap-2" data-testid="button-contact">
                    Get in Touch
                  </button>
                </Link>
              </div>
            </div>
          </ScrollReveal>

          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: SiPython, label: "Python", desc: "Problems solved, scripts automated, APIs built", delay: 0 },
              { icon: Brain, label: "ML Models", desc: "Training pipelines, fine-tuning, evaluation", delay: 100 },
              { icon: SiOpenai, label: "AI Systems", desc: "LLMs, RAG, ChatGPT-style deployments", delay: 200 },
            ].map(({ icon: Icon, label, desc, delay }) => (
              <ScrollReveal key={label} direction="up" delay={delay}>
                <div
                  className="glass-card-teal rounded-xl p-6 transition-all duration-300 group floating"
                  style={{ animationDelay: `${delay * 0.003}s` }}
                  data-testid={`card-skill-${label.toLowerCase()}`}
                >
                  <Icon className="w-8 h-8 mb-3 group-hover:scale-110 transition-transform" style={{ color: "hsl(173 80% 42%)", filter: "drop-shadow(0 0 8px hsl(173 80% 42% / 0.6))" }} />
                  <h3 className="font-mono font-semibold text-foreground mb-1">{label}</h3>
                  <p className="text-sm text-muted-foreground">{desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section className="py-24 border-t border-white/5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <ScrollReveal direction="left">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight">
                  The specialist you need, not{" "}
                  <span className="text-muted-foreground">another generalist</span>
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Whether you're stuck on a Python assignment, need an ML model trained from scratch, or want to build your own AI chatbot — I deliver working solutions, not tutorials.
                </p>
                <ul className="space-y-3">
                  {[
                    "Python debugging, automation, and API development",
                    "ML model training with scikit-learn, TensorFlow, PyTorch",
                    "AI chatbots and LLM-powered applications",
                    "Custom AI pipelines for your specific use case",
                  ].map((item) => (
                    <li key={item} className="flex gap-3 text-sm text-muted-foreground">
                      <Zap className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "hsl(173 80% 42%)", filter: "drop-shadow(0 0 4px hsl(173 80% 42% / 0.6))" }} />
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-8">
                  <Link href="/services">
                    <button className="glow-btn-outline font-mono text-sm font-medium px-5 py-2.5 rounded-lg text-foreground flex items-center gap-2" data-testid="button-explore-services">
                      Explore Services <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </div>
            </ScrollReveal>

            <ScrollReveal direction="right">
              <div className="relative">
                <div
                  className="glass-card rounded-xl p-6 font-mono text-sm leading-relaxed"
                  style={{ boxShadow: "0 0 40px rgba(20,184,166,0.1), 0 20px 60px rgba(0,0,0,0.4)" }}
                >
                  <div className="flex gap-2 mb-4">
                    <div className="w-3 h-3 rounded-full bg-red-500/70" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
                    <div className="w-3 h-3 rounded-full" style={{ background: "hsl(173 80% 42% / 0.8)" }} />
                  </div>
                  <div className="space-y-1">
                    <p><span className="text-accent">import</span> <span className="text-primary">torch</span></p>
                    <p><span className="text-accent">from</span> <span className="text-primary">transformers</span> <span className="text-accent">import</span> AutoModelForCausalLM</p>
                    <p className="text-muted-foreground mt-2"># Training your custom AI model</p>
                    <p><span className="text-foreground">model</span> <span className="text-accent">=</span> AutoModelForCausalLM.from_pretrained(</p>
                    <p className="pl-4"><span className="text-primary">"your-base-model"</span></p>
                    <p>)</p>
                    <p className="text-muted-foreground mt-2"># Fine-tuned. Deployed. Done.</p>
                    <p><span className="text-primary">print</span>(<span className="text-accent">"Model ready ✓"</span>)</p>
                  </div>
                </div>
                <div className="absolute -bottom-3 -right-3 w-full h-full rounded-xl -z-10" style={{ border: "1px solid hsl(173 80% 42% / 0.2)", boxShadow: "0 0 30px hsl(173 80% 42% / 0.1)" }} />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 border-t border-white/5">
        <div className="container mx-auto px-4">
          <ScrollReveal direction="up">
            <div className="text-center mb-12">
              <Badge className="mb-4 font-mono text-xs px-3 py-1" style={{
                background: "rgba(20,184,166,0.1)",
                border: "1px solid rgba(20,184,166,0.3)",
                color: "hsl(173 80% 42%)",
              }}>
                FAQ
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-3">
                Common <span className="gradient-text">Questions</span>
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Everything you need to know before reaching out.
              </p>
            </div>
          </ScrollReveal>
          <div className="max-w-2xl mx-auto space-y-3">
            {faqs.map((faq, i) => (
              <FAQItem key={i} q={faq.q} a={faq.a} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 border-t border-white/5">
        <div className="container mx-auto px-4 text-center">
          <ScrollReveal direction="up">
            <div
              className="rounded-2xl p-12 relative overflow-hidden"
              style={{
                background: "linear-gradient(135deg, rgba(20,184,166,0.08), rgba(139,92,246,0.06))",
                border: "1px solid rgba(20,184,166,0.2)",
                boxShadow: "0 0 60px rgba(20,184,166,0.08)",
              }}
            >
              <div className="absolute inset-0 ai-grid opacity-30" />
              <div className="relative z-10">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">Ready to start?</h2>
                <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
                  Describe your problem or project. I'll review it and get back with a solution approach and timeline.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/contact">
                    <button className="glow-btn font-mono text-sm font-medium px-8 py-3 rounded-lg text-white flex items-center gap-2 mx-auto" data-testid="button-start-project">
                      Start a Project <ArrowRight className="w-4 h-4" />
                    </button>
                  </Link>
                  <button
                    className="glow-btn-outline font-mono text-sm font-medium px-8 py-3 rounded-lg text-muted-foreground flex items-center gap-2 mx-auto"
                    onClick={() => document.querySelector<HTMLButtonElement>('[data-testid="button-open-chatbot"]')?.click()}
                    data-testid="button-ask-chatbot"
                  >
                    <Cpu className="w-4 h-4" /> Ask AI about Ubaid
                  </button>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </Layout>
  );
}
