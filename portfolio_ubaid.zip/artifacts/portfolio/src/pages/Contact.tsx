import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useSubmitContact } from "@workspace/api-client-react";
import { useState } from "react";
import { Send, Mail, MessageSquare, User } from "lucide-react";
import { ScrollReveal } from "@/components/ScrollReveal";

export default function Contact() {
  const { toast } = useToast();
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const submitContact = useSubmitContact({
    mutation: {
      onSuccess: () => {
        setSubmitted(true);
        setForm({ name: "", email: "", subject: "", message: "" });
        toast({ title: "Message sent", description: "I'll get back to you soon." });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to send message. Please try again.", variant: "destructive" });
      },
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.subject || !form.message) return;
    submitContact.mutate({ data: form });
  };

  return (
    <Layout>
      <section className="py-20 border-b border-border/30">
        <div className="container mx-auto px-4">
          <ScrollReveal direction="up">
            <div className="max-w-2xl">
              <Badge className="mb-4 font-mono text-xs border-primary/40 text-primary bg-primary/10 px-3 py-1">
                Contact
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                Let's talk about your project
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Describe what you're trying to build or solve. I respond within 24 hours with a plan.
              </p>
            </div>
          </ScrollReveal>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <ScrollReveal direction="left">
              <div>
                {submitted ? (
                  <div className="border border-primary/30 rounded-xl p-10 bg-primary/5 text-center" data-testid="contact-success">
                    <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center mx-auto mb-4">
                      <Send className="w-8 h-8 text-primary" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Message received</h2>
                    <p className="text-muted-foreground mb-6">I'll review your project and respond within 24 hours.</p>
                    <Button
                      variant="outline"
                      className="font-mono border-primary/40 hover:border-primary hover:text-primary"
                      onClick={() => setSubmitted(false)}
                      data-testid="button-send-another"
                    >
                      Send another message
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6" data-testid="form-contact">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                        Name
                      </Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="name"
                          placeholder="Your name"
                          value={form.name}
                          onChange={(e) => setForm({ ...form, name: e.target.value })}
                          className="pl-10 bg-card border-border/60 focus:border-primary font-mono"
                          data-testid="input-name"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                        Email
                      </Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          value={form.email}
                          onChange={(e) => setForm({ ...form, email: e.target.value })}
                          className="pl-10 bg-card border-border/60 focus:border-primary font-mono"
                          data-testid="input-email"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="subject" className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                        Subject
                      </Label>
                      <div className="relative">
                        <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="subject"
                          placeholder="What do you need help with?"
                          value={form.subject}
                          onChange={(e) => setForm({ ...form, subject: e.target.value })}
                          className="pl-10 bg-card border-border/60 focus:border-primary font-mono"
                          data-testid="input-subject"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message" className="font-mono text-xs text-muted-foreground uppercase tracking-wider">
                        Message
                      </Label>
                      <Textarea
                        id="message"
                        placeholder="Describe your project, problem, or what you're trying to build..."
                        value={form.message}
                        onChange={(e) => setForm({ ...form, message: e.target.value })}
                        className="bg-card border-border/60 focus:border-primary font-mono min-h-[160px] resize-none"
                        data-testid="textarea-message"
                        required
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full font-mono gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                      disabled={submitContact.isPending}
                      data-testid="button-submit-contact"
                    >
                      {submitContact.isPending ? "Sending..." : "Send Message"}
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                )}
              </div>
            </ScrollReveal>

            <ScrollReveal direction="right" delay={100}>
              <div className="space-y-6">
                <div className="border border-border/40 rounded-xl p-6 bg-card/30">
                  <h3 className="font-mono font-semibold mb-2 text-primary">Response time</h3>
                  <p className="text-sm text-muted-foreground">I typically respond within 24 hours. For urgent projects, mention it in your message.</p>
                </div>
                <div className="border border-border/40 rounded-xl p-6 bg-card/30">
                  <h3 className="font-mono font-semibold mb-2 text-primary">What to include</h3>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• What problem you're trying to solve</li>
                    <li>• Your tech stack or constraints (if any)</li>
                    <li>• Deadline or timeline expectations</li>
                    <li>• Your budget range (optional)</li>
                  </ul>
                </div>
                <div className="border border-border/40 rounded-xl p-6 bg-card/30">
                  <h3 className="font-mono font-semibold mb-3 text-primary">Services available</h3>
                  <div className="flex flex-wrap gap-2">
                    {["Python", "ML Training", "AI Systems", "ChatGPT-style AI", "Debugging", "Automation"].map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs font-mono border-border/60 text-muted-foreground">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>
    </Layout>
  );
}
