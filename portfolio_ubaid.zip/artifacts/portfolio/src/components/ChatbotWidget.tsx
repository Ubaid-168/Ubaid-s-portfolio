import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Send, Mic, MicOff, Volume2, VolumeX, Sparkles } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
}

async function createConversation(): Promise<number> {
  const res = await fetch("/api/openai/conversations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: "Portfolio Chat" }),
  });
  if (!res.ok) throw new Error("Failed to create conversation");
  const data = await res.json() as { id: number };
  return data.id;
}

export function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hi! I'm Ubaid's AI assistant. Ask me about his skills, projects, education, or services — in any language!",
    },
  ]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [recording, setRecording] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [voiceLoading, setVoiceLoading] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 100);
  }, [open]);

  const getOrCreateConversation = useCallback(async (): Promise<number> => {
    if (conversationId) return conversationId;
    const id = await createConversation();
    setConversationId(id);
    return id;
  }, [conversationId]);

  const playTts = useCallback(async (text: string) => {
    if (!voiceEnabled || !text) return;
    try {
      setVoiceLoading(true);
      const res = await fetch("/api/openai/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.onended = () => URL.revokeObjectURL(url);
      await audio.play();
    } catch {
    } finally {
      setVoiceLoading(false);
    }
  }, [voiceEnabled]);

  const sendMessage = useCallback(async (textOverride?: string) => {
    const text = (textOverride ?? input).trim();
    if (!text || streaming) return;

    if (!textOverride) setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setStreaming(true);
    setMessages((prev) => [...prev, { role: "assistant", content: "", streaming: true }]);

    try {
      const convId = await getOrCreateConversation();

      const response = await fetch(`/api/openai/conversations/${convId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6)) as { content?: string; done?: boolean };
              if (data.content) {
                fullText += data.content;
                setMessages((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.role === "assistant") {
                    updated[updated.length - 1] = { ...last, content: last.content + data.content };
                  }
                  return updated;
                });
              }
              if (data.done) {
                setMessages((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.role === "assistant") {
                    updated[updated.length - 1] = { ...last, streaming: false };
                  }
                  return updated;
                });
                if (fullText) void playTts(fullText);
              }
            } catch { }
          }
        }
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong";
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last?.role === "assistant") {
          updated[updated.length - 1] = { ...last, content: `Error: ${msg}`, streaming: false };
        }
        return updated;
      });
    } finally {
      setStreaming(false);
    }
  }, [input, streaming, getOrCreateConversation, playTts]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void sendMessage();
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
      const recorder = new MediaRecorder(stream, { mimeType });
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        const arrayBuffer = await blob.arrayBuffer();
        const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
        try {
          const res = await fetch("/api/openai/transcribe", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ audio: base64, mimeType }),
          });
          if (res.ok) {
            const { text } = await res.json() as { text: string };
            if (text?.trim()) {
              void sendMessage(text.trim());
            }
          }
        } catch { }
        setRecording(false);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } catch {
      setRecording(false);
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
  };

  const handleMicClick = () => {
    if (recording) {
      stopRecording();
    } else {
      void startRecording();
    }
  };

  const glowTeal = "hsl(173 80% 42%)";
  const glowPurple = "hsl(280 80% 62%)";

  return (
    <>
      {open && (
        <div
          className="fixed bottom-24 right-4 w-80 md:w-96 z-50 rounded-2xl shadow-2xl flex flex-col"
          style={{
            height: "480px",
            background: "rgba(8, 18, 30, 0.95)",
            backdropFilter: "blur(24px)",
            border: `1px solid rgba(20,184,166,0.35)`,
            boxShadow: `0 0 40px rgba(20,184,166,0.18), 0 20px 60px rgba(0,0,0,0.6)`,
          }}
          data-testid="chatbot-panel"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3" style={{ borderBottom: "1px solid rgba(20,184,166,0.2)" }}>
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{
                  background: `linear-gradient(135deg, ${glowTeal}33, ${glowPurple}33)`,
                  border: `1px solid ${glowTeal}88`,
                  boxShadow: `0 0 14px ${glowTeal}55`,
                }}
              >
                <Sparkles className="w-4 h-4" style={{ color: glowTeal }} />
              </div>
              <div>
                <p className="text-sm font-mono font-semibold" style={{
                  background: `linear-gradient(90deg, ${glowTeal}, ${glowPurple})`,
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}>
                  Ask AI about Ubaid
                </p>
                <p className="text-xs text-muted-foreground">Any language · Skills · Projects</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setVoiceEnabled((v) => !v)}
                className="h-7 w-7 rounded flex items-center justify-center transition-colors hover:bg-white/5"
                style={{ color: voiceEnabled ? glowTeal : "hsl(215 20% 55%)" }}
                title={voiceEnabled ? "Disable voice reply" : "Enable voice reply"}
              >
                {voiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setOpen(false)}
                className="h-7 w-7 rounded flex items-center justify-center transition-colors hover:bg-white/5 text-muted-foreground hover:text-foreground"
                data-testid="button-close-chatbot"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                data-testid={`message-${msg.role}-${i}`}
              >
                {msg.role === "assistant" && (
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{
                      background: `linear-gradient(135deg, ${glowTeal}22, ${glowPurple}22)`,
                      border: `1px solid ${glowTeal}55`,
                    }}
                  >
                    <Sparkles className="w-3 h-3" style={{ color: glowTeal }} />
                  </div>
                )}
                <div
                  className="max-w-[80%] rounded-xl px-3 py-2 text-sm leading-relaxed"
                  style={
                    msg.role === "user"
                      ? {
                          background: `linear-gradient(135deg, ${glowTeal}cc, ${glowTeal}99)`,
                          color: "white",
                          boxShadow: `0 0 12px ${glowTeal}44`,
                        }
                      : {
                          background: "rgba(255,255,255,0.05)",
                          border: "1px solid rgba(255,255,255,0.1)",
                          color: "hsl(210 40% 95%)",
                        }
                  }
                >
                  {msg.content || (msg.streaming ? (
                    <span className="flex gap-1 items-center py-0.5">
                      {[0, 150, 300].map((delay) => (
                        <span
                          key={delay}
                          className="w-1.5 h-1.5 rounded-full animate-bounce"
                          style={{ background: glowTeal, animationDelay: `${delay}ms` }}
                        />
                      ))}
                    </span>
                  ) : "")}
                </div>
                {msg.role === "user" && (
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 font-mono text-xs font-bold"
                    style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)", color: "hsl(215 20% 65%)" }}
                  >
                    U
                  </div>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="px-4 py-3" style={{ borderTop: "1px solid rgba(20,184,166,0.2)" }}>
            {voiceLoading && (
              <p className="text-xs font-mono text-center mb-2" style={{ color: glowTeal }}>
                🔊 Speaking...
              </p>
            )}
            {recording && (
              <p className="text-xs font-mono text-center mb-2 animate-pulse" style={{ color: glowTeal }}>
                🎙 Recording... tap mic to stop
              </p>
            )}
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                placeholder="Ask anything... in any language"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={streaming}
                className="font-mono text-sm h-9"
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: `1px solid rgba(20,184,166,0.3)`,
                  color: "hsl(210 40% 98%)",
                }}
                data-testid="input-chatbot-message"
              />
              <button
                onClick={handleMicClick}
                disabled={streaming}
                className="h-9 w-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-all"
                style={{
                  color: recording ? glowTeal : "hsl(215 20% 55%)",
                  background: recording ? `${glowTeal}22` : "rgba(255,255,255,0.05)",
                  border: `1px solid ${recording ? glowTeal : "rgba(255,255,255,0.1)"}`,
                  boxShadow: recording ? `0 0 12px ${glowTeal}55` : "none",
                }}
                title="Voice input"
              >
                {recording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
              <button
                onClick={() => void sendMessage()}
                disabled={streaming || !input.trim()}
                className="h-9 w-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-all disabled:opacity-40"
                style={{
                  background: `linear-gradient(135deg, ${glowTeal}, hsl(173 80% 30%))`,
                  boxShadow: `0 0 16px ${glowTeal}55`,
                }}
                data-testid="button-send-chatbot"
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating button */}
      <button
        className="fixed bottom-4 right-4 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
        style={{
          background: `linear-gradient(135deg, ${glowTeal}, ${glowPurple})`,
          boxShadow: open
            ? `0 0 30px ${glowTeal}cc, 0 0 60px ${glowPurple}66`
            : `0 0 20px ${glowTeal}88, 0 4px 20px rgba(0,0,0,0.5)`,
        }}
        onClick={() => setOpen((v) => !v)}
        data-testid="button-open-chatbot"
      >
        {open ? <X className="w-6 h-6 text-white" /> : <Sparkles className="w-6 h-6 text-white" />}
      </button>
    </>
  );
}
