import { useEffect, useState } from "react";

export function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState(0);

  const phases = ["Initializing AI...", "Loading portfolio...", "Welcome, Ubaid."];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        const next = p + Math.random() * 18 + 5;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(onDone, 400);
          return 100;
        }
        return next;
      });
    }, 120);
    return () => clearInterval(interval);
  }, [onDone]);

  useEffect(() => {
    if (progress > 33) setPhase(1);
    if (progress > 75) setPhase(2);
  }, [progress]);

  return (
    <div className="fixed inset-0 z-[9999] bg-[#050d15] flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-px opacity-20 animate-pulse"
            style={{
              left: `${(i / 20) * 100}%`,
              top: 0,
              height: "100%",
              background: "linear-gradient(to bottom, transparent, hsl(173 80% 40%), transparent)",
              animationDelay: `${i * 0.15}s`,
              animationDuration: `${1.5 + (i % 4) * 0.5}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center gap-8 w-80">
        <div className="relative">
          <div
            className="w-24 h-24 rounded-full border-2 flex items-center justify-center"
            style={{
              borderColor: "hsl(173 80% 40%)",
              boxShadow: "0 0 40px hsl(173 80% 40% / 0.6), 0 0 80px hsl(173 80% 40% / 0.3)",
              animation: "spin 3s linear infinite",
            }}
          >
            <div
              className="w-16 h-16 rounded-full border border-dashed flex items-center justify-center"
              style={{
                borderColor: "hsl(280 80% 60%)",
                boxShadow: "0 0 20px hsl(280 80% 60% / 0.4)",
                animation: "spin 2s linear infinite reverse",
              }}
            >
              <span className="font-mono text-lg font-bold" style={{ color: "hsl(173 80% 40%)" }}>U</span>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h1
            className="font-mono text-2xl font-bold mb-1"
            style={{
              background: "linear-gradient(90deg, hsl(173 80% 40%), hsl(280 80% 60%))",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Ubaid's Portfolio
          </h1>
          <p className="font-mono text-xs text-muted-foreground tracking-widest uppercase">
            AI · ML · Python Specialist
          </p>
        </div>

        <div className="w-full">
          <div className="flex justify-between mb-2">
            <span className="font-mono text-xs" style={{ color: "hsl(173 80% 40%)" }}>
              {phases[phase]}
            </span>
            <span className="font-mono text-xs text-muted-foreground">{Math.round(progress)}%</span>
          </div>
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-150"
              style={{
                width: `${progress}%`,
                background: "linear-gradient(90deg, hsl(173 80% 40%), hsl(280 80% 60%))",
                boxShadow: "0 0 10px hsl(173 80% 40%)",
              }}
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 w-full">
          {["Python", "ML", "AI"].map((label, i) => (
            <div
              key={label}
              className="text-center py-1 rounded border font-mono text-xs transition-all duration-300"
              style={{
                borderColor: progress > (i + 1) * 25 ? "hsl(173 80% 40%)" : "hsl(217 33% 17%)",
                color: progress > (i + 1) * 25 ? "hsl(173 80% 40%)" : "hsl(215 20% 65%)",
                background: progress > (i + 1) * 25 ? "hsl(173 80% 40% / 0.1)" : "transparent",
              }}
            >
              {label}
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
