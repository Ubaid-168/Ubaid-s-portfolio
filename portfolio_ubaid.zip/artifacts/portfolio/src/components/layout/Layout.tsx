import { ReactNode, useState } from "react";
import { Nav } from "./Nav";
import { Footer } from "./Footer";
import { ChatbotWidget } from "../ChatbotWidget";
import { LoadingScreen } from "../LoadingScreen";
import { WhatsAppButton } from "../WhatsAppButton";

export function Layout({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(() => {
    const seen = sessionStorage.getItem("portfolio_loaded");
    return !seen;
  });

  const handleDone = () => {
    sessionStorage.setItem("portfolio_loaded", "1");
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col font-sans dark">
      {loading && <LoadingScreen onDone={handleDone} />}
      <Nav />
      <main className="flex-grow">{children}</main>
      <Footer />
      <ChatbotWidget />
      <WhatsAppButton />
    </div>
  );
}
