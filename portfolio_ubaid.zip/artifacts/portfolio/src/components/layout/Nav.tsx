import { Link } from "wouter";

export function Nav() {
  return (
    <nav
      className="border-b border-white/10 sticky top-0 z-50 backdrop-blur-xl"
      style={{
        background: "rgba(5, 13, 21, 0.85)",
        borderBottom: "1px solid rgba(20, 184, 166, 0.2)",
      }}
    >
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="font-mono font-bold text-xl tracking-tighter" style={{
          background: "linear-gradient(90deg, hsl(173 80% 40%), hsl(280 80% 60%))",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          Ubaid's Portfolio
        </Link>
        <div className="flex items-center space-x-6 text-sm font-medium">
          <Link href="/" className="hover:text-primary transition-colors text-muted-foreground">
            Home
          </Link>
          <Link href="/services" className="hover:text-primary transition-colors text-muted-foreground">
            Services
          </Link>
          <Link href="/contact" className="hover:text-primary transition-colors text-muted-foreground">
            Contact
          </Link>
        </div>
      </div>
    </nav>
  );
}
