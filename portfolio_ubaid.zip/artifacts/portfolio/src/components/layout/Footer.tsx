import { Link } from "wouter";

export function Footer() {
  return (
    <footer
      className="border-t py-8"
      style={{ borderColor: "rgba(20,184,166,0.15)", background: "rgba(5,13,21,0.8)" }}
    >
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <span
          className="font-mono text-sm font-semibold"
          style={{
            background: "linear-gradient(90deg, hsl(173 80% 40%), hsl(280 80% 60%))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Ubaid's Portfolio — Python · ML · AI
        </span>
        <div className="flex gap-6 text-xs font-mono text-muted-foreground">
          <Link href="/" className="hover:text-primary transition-colors">Home</Link>
          <Link href="/services" className="hover:text-primary transition-colors">Services</Link>
          <Link href="/contact" className="hover:text-primary transition-colors">Contact</Link>
          <a
            href="https://wa.me/923051710343"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-green-400 transition-colors"
          >
            WhatsApp
          </a>
        </div>
      </div>
    </footer>
  );
}
