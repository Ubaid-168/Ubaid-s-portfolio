# Developer Portfolio

A portfolio website for a coding/AI specialist offering Python problem solving, ML model training, and AI system building services. Includes a contact form and an AI-powered chatbot.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/portfolio run dev` — run the portfolio frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `AI_INTEGRATIONS_OPENAI_BASE_URL` + `AI_INTEGRATIONS_OPENAI_API_KEY` — OpenAI via Replit AI Integrations

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + TailwindCSS + shadcn/ui + wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- AI: OpenAI via Replit AI Integrations (gpt-5-mini for chatbot)
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for API contracts)
- `lib/db/src/schema/` — Drizzle DB schemas (contact.ts, conversations.ts, messages.ts)
- `artifacts/portfolio/src/pages/` — Home, Services, Contact pages
- `artifacts/portfolio/src/components/ChatbotWidget.tsx` — floating AI chatbot
- `artifacts/api-server/src/routes/contact.ts` — contact form API
- `artifacts/api-server/src/routes/openai/index.ts` — chatbot/AI API

## Architecture decisions

- Contract-first OpenAPI spec with Orval codegen for typed hooks and Zod schemas
- SSE streaming for chatbot responses (raw fetch on client, streaming completions on server)
- Chatbot system prompt is hardcoded in the API route with the owner's service description
- All DB tables: contact_messages, conversations, messages
- Dark theme by default (no toggle) — suits the technical/dev brand

## Product

- **Home page**: Hero with tagline, skill cards, about section, CTA
- **Services page**: Python, ML, AI service cards with features and inquiry buttons
- **Contact page**: Contact form (name, email, subject, message) with success state
- **Chatbot widget**: Floating button (bottom-right), SSE-streamed AI responses, persisted conversation

## User preferences

- Services: Python problem solving, ML model training, AI system building (like ChatGPT)
- Target audience: Students and teams needing real coding/AI help

## Gotchas

- After each OpenAPI spec change, run `pnpm --filter @workspace/api-spec run codegen`
- Chatbot SSE streaming uses raw `fetch` + `ReadableStream` — NOT generated React Query hooks
- Schema naming in OpenAPI: use entity-shaped names (e.g. `OpenaiConversationInput`, not `CreateOpenaiConversationBody`) to avoid Orval collision errors

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See the `ai-integrations-openai` skill for AI/chatbot setup details
